# 武 Bushido 90

Become your strongest self. An AI-powered Life OS for a 90-day challenge.

## Quickstart (on your machine)

```bash
npm install                 # also runs prisma generate
cp .env.example .env.local  # fill in Supabase keys (see below)
npm run db:migrate          # creates all tables
npm run db:seed             # seeds the metric registry
npm run dev                 # → http://localhost:3000
```

## Supabase (one-time, ~3 min)
1. Create a free project at supabase.com
2. Settings → API → copy URL + anon key into .env.local
3. Settings → Database → copy pooled (6543) URL as DATABASE_URL and
   direct (5432) URL as DIRECT_URL
4. Authentication → URL Configuration → add redirect:
   `http://localhost:3000/api/auth/callback`

## Or let Claude Code drive
This repo ships with CLAUDE.md. Install Claude Code, then:

```bash
cd bushido-90
claude
```

and ask it to finish setup and run the app. It will read CLAUDE.md,
install, migrate, seed, launch, and debug any errors with you.

## What works today
Auth (email + Google), protected app shell (animated sidebar, mobile
nav), live dashboard (streak, XP, scores, today's mission with optimistic
task toggling, hydration logging, vitals). Other sidebar routes show a
"coming phase" page — they're the next build phases.
