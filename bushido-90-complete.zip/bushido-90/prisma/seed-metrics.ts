/**
 * Seeds the metric registry (idempotent).
 * Run: npx tsx prisma/seed-metrics.ts
 */
import { PrismaClient, MetricCategory, MetricValueType, MetricAggregation } from "@prisma/client";

const prisma = new PrismaClient();

const METRICS = [
  { key: "water_intake", name: "Water", category: MetricCategory.HEALTH, valueType: MetricValueType.NUMBER, unit: "ml", icon: "Droplets", aggregation: MetricAggregation.SUM, sortOrder: 1 },
  { key: "sleep_duration", name: "Sleep", category: MetricCategory.HEALTH, valueType: MetricValueType.DURATION, unit: "min", icon: "Moon", aggregation: MetricAggregation.SUM, sortOrder: 2 },
  { key: "weight", name: "Weight", category: MetricCategory.HEALTH, valueType: MetricValueType.NUMBER, unit: "kg", icon: "Scale", aggregation: MetricAggregation.LAST, sortOrder: 3 },
  { key: "steps", name: "Steps", category: MetricCategory.HEALTH, valueType: MetricValueType.NUMBER, unit: "steps", icon: "Footprints", aggregation: MetricAggregation.SUM, sortOrder: 4 },
  { key: "reading", name: "Reading", category: MetricCategory.MIND, valueType: MetricValueType.DURATION, unit: "min", icon: "BookOpen", aggregation: MetricAggregation.SUM, sortOrder: 5 },
  { key: "meditation", name: "Meditation", category: MetricCategory.MIND, valueType: MetricValueType.DURATION, unit: "min", icon: "Wind", aggregation: MetricAggregation.SUM, sortOrder: 6 },
  { key: "mood", name: "Mood", category: MetricCategory.LIFESTYLE, valueType: MetricValueType.RATING, unit: "1-5", icon: "Smile", aggregation: MetricAggregation.LAST, minValue: 1, maxValue: 5, sortOrder: 7 },
  { key: "energy", name: "Energy", category: MetricCategory.LIFESTYLE, valueType: MetricValueType.RATING, unit: "1-5", icon: "Zap", aggregation: MetricAggregation.LAST, minValue: 1, maxValue: 5, sortOrder: 8 },
];

async function main() {
  for (const m of METRICS) {
    await prisma.metricDefinition.upsert({
      where: { key: m.key },
      update: m,
      create: m,
    });
  }
  console.log(`Seeded ${METRICS.length} metric definitions.`);
}

main().finally(() => prisma.$disconnect());
