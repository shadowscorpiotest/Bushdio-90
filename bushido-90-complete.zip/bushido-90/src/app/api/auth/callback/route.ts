import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { ensureUserRecord } from "@/actions/auth.actions";

/**
 * Handles OAuth sign-in, email confirmation, and password-recovery
 * links. Exchanges the code for a session, provisions the app user
 * record (idempotent), then forwards to the requested destination.
 */
export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const rawNext = searchParams.get("next") ?? "/dashboard";
  const next = rawNext.startsWith("/") ? rawNext : "/dashboard";

  if (code) {
    const supabase = await createClient();
    const { data, error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error && data.user) {
      await ensureUserRecord({
        id: data.user.id,
        email: data.user.email ?? "",
        displayName:
          (data.user.user_metadata?.display_name as string) ??
          (data.user.user_metadata?.full_name as string) ??
          null,
        avatarUrl: (data.user.user_metadata?.avatar_url as string) ?? null,
      });
      return NextResponse.redirect(`${origin}${next}`);
    }
  }

  return NextResponse.redirect(`${origin}/login?error=auth_callback`);
}
