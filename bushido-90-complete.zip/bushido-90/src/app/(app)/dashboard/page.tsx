import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { getDashboardData } from "@/services/db/dashboard.service";
import { DashboardView } from "@/features/dashboard/components/dashboard-view";

export const metadata: Metadata = { title: "Dashboard" };

export default async function DashboardPage() {
  const user = await requireUser();
  const data = await getDashboardData(user.id);
  return <DashboardView data={data} />;
}
