import type { ReactNode } from "react";
import { requireUser } from "@/lib/auth";
import { AppShell } from "@/components/layout/app-shell";

export default async function AppLayout({ children }: { children: ReactNode }) {
  await requireUser(); // middleware guards too — this is defense in depth
  return <AppShell>{children}</AppShell>;
}
