import Link from "next/link";
import { NAV } from "@/config/nav";

/**
 * Catch-all for routes whose phases haven't shipped yet.
 * Explicit routes (e.g. /dashboard) always take precedence.
 */
export default async function ComingSoon({
  params,
}: {
  params: Promise<{ soon: string[] }>;
}) {
  const { soon } = await params;
  const item = NAV.find((n) => n.href === `/${soon[0]}`);

  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center text-center">
      <span className="mb-4 text-4xl text-gold/30">武</span>
      <h1 className="text-lg font-semibold">
        {item?.label ?? "This page"} is a coming phase
      </h1>
      <p className="mt-2 max-w-sm text-[13px] font-light text-white/40">
        The dojo is built room by room. This one is on the blueprint —
        the dashboard is already open.
      </p>
      <Link
        href="/dashboard"
        className="mt-6 rounded-xl bg-gradient-to-b from-gold to-gold-deep px-5 py-2.5 text-[13px] font-semibold text-base shadow-gold-glow transition-all hover:brightness-105 active:scale-95"
      >
        Back to Dashboard
      </Link>
    </div>
  );
}
