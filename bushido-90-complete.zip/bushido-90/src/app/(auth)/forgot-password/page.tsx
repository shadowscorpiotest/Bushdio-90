import type { Metadata } from "next";
import { ForgotPasswordForm } from "@/features/auth/components/forgot-password-form";

export const metadata: Metadata = { title: "Reset password — Bushido 90" };

export default function ForgotPasswordPage() {
  return <ForgotPasswordForm />;
}
