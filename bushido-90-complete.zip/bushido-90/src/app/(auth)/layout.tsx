import type { ReactNode } from "react";

/**
 * Auth shell — full-bleed #0B0B0C with a single ambient gold glow
 * and a faint 武 (bu — "warrior") watermark. The card floats center.
 */
export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="relative flex min-h-dvh items-center justify-center overflow-hidden bg-[#0B0B0C] px-4 py-12">
      {/* Ambient gold glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-[-20%] h-[60vh] w-[80vw] -translate-x-1/2 rounded-full bg-[#D4AF37]/[0.07] blur-[120px]"
      />
      {/* Kanji watermark */}
      <div
        aria-hidden
        className="pointer-events-none absolute right-[-4rem] bottom-[-6rem] select-none text-[24rem] font-bold leading-none text-white/[0.02]"
      >
        武
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Wordmark */}
        <div className="mb-10 flex flex-col items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-[#2A2A2D] bg-[#151517] text-xl text-[#D4AF37] shadow-[0_0_40px_-8px_rgba(212,175,55,0.35)]">
            武
          </div>
          <div className="text-center">
            <p className="text-sm font-semibold tracking-[0.35em] text-white">
              BUSHIDO&nbsp;90
            </p>
            <p className="mt-1 text-xs font-light tracking-wide text-white/40">
              Become your strongest self
            </p>
          </div>
        </div>

        {children}
      </div>
    </div>
  );
}
