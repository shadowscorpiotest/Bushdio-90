import type { Variants } from "framer-motion";

/** Shared motion language — one easing, used everywhere. */
export const EASE = [0.22, 1, 0.36, 1] as const;
export const SPRING_POP = { type: "spring", stiffness: 420, damping: 22 } as const;

export const fadeUp: Variants = {
  hidden: { opacity: 0, y: 14 },
  show: { opacity: 1, y: 0, transition: { duration: 0.55, ease: EASE } },
};

export const stagger: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.07, delayChildren: 0.05 } },
};
