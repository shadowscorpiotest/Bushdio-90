import { cache } from "react";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";

/** Cached per-request: safe to call from many components. */
export const getUser = cache(async () => {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  return user;
});

/** Guard for protected pages and server actions. */
export async function requireUser() {
  const user = await getUser();
  if (!user) redirect("/login");
  return user;
}

/** Full app profile (Prisma row + settings) for the signed-in user. */
export const getProfile = cache(async () => {
  const user = await requireUser();
  return prisma.user.findUnique({
    where: { id: user.id },
    include: { settings: true },
  });
});
