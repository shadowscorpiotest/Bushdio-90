import { prisma } from "@/lib/prisma";
import { localToday, localHour, challengeDay } from "@/utils/dates";

/**
 * One aggregated read for the dashboard. Runs as parallel queries
 * inside a single server render — no client waterfalls.
 */
export async function getDashboardData(userId: string) {
  const profile = await prisma.user.findUniqueOrThrow({
    where: { id: userId },
    include: { settings: true },
  });

  const tz = profile.timezone;
  const today = localToday(tz);

  const [summary, tasks, waterAgg] = await Promise.all([
    prisma.dailySummary.findUnique({
      where: { userId_date: { userId, date: today } },
    }),
    prisma.task.findMany({
      where: {
        userId,
        scheduledDate: today,
        status: { notIn: ["CANCELLED"] },
      },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
      take: 8,
      select: { id: true, title: true, status: true, priority: true },
    }),
    prisma.metricLog.aggregate({
      where: { userId, date: today, metric: { key: "water_intake" } },
      _sum: { value: true },
    }),
  ]);

  return {
    profile,
    today,
    hour: localHour(tz),
    day: challengeDay(profile.challengeStartDate, today),
    scores: {
      bushido: summary?.bushidoScore ?? 0,
      life: summary?.lifeScore ?? 0,
      health: summary?.healthScore ?? 0,
      mind: summary?.mindScore ?? 0,
    },
    vitals: {
      sleepMin: summary?.sleepMin ?? 0,
      deepWorkMin: summary?.deepWorkMin ?? 0,
      workoutDone: summary?.workoutDone ?? false,
    },
    tasks,
    waterMl: Math.round(waterAgg._sum.value ?? 0),
  };
}

export type DashboardData = Awaited<ReturnType<typeof getDashboardData>>;
