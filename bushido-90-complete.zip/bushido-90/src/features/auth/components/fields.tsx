"use client";

import { useId, useState, type InputHTMLAttributes } from "react";
import { Eye, EyeOff, Loader2 } from "lucide-react";

type TextFieldProps = InputHTMLAttributes<HTMLInputElement> & {
  label: string;
  error?: string;
};

export function TextField({ label, error, id, ...props }: TextFieldProps) {
  const autoId = useId();
  const fieldId = id ?? autoId;

  return (
    <div className="space-y-1.5">
      <label
        htmlFor={fieldId}
        className="block text-xs font-medium tracking-wide text-white/60"
      >
        {label}
      </label>
      <input
        id={fieldId}
        aria-invalid={!!error}
        aria-describedby={error ? `${fieldId}-error` : undefined}
        className="h-11 w-full rounded-xl border border-[#2A2A2D] bg-[#0B0B0C] px-3.5 text-sm text-white placeholder:text-white/25 outline-none transition-colors duration-200 focus:border-[#D4AF37]/60 focus:ring-2 focus:ring-[#D4AF37]/15 aria-[invalid=true]:border-[#E5484D]/60"
        {...props}
      />
      {error && (
        <p id={`${fieldId}-error`} className="text-xs text-[#E5484D]">
          {error}
        </p>
      )}
    </div>
  );
}

export function PasswordField({ label, error, id, ...props }: TextFieldProps) {
  const autoId = useId();
  const fieldId = id ?? autoId;
  const [visible, setVisible] = useState(false);

  return (
    <div className="space-y-1.5">
      <label
        htmlFor={fieldId}
        className="block text-xs font-medium tracking-wide text-white/60"
      >
        {label}
      </label>
      <div className="relative">
        <input
          id={fieldId}
          type={visible ? "text" : "password"}
          aria-invalid={!!error}
          aria-describedby={error ? `${fieldId}-error` : undefined}
          className="h-11 w-full rounded-xl border border-[#2A2A2D] bg-[#0B0B0C] px-3.5 pr-11 text-sm text-white placeholder:text-white/25 outline-none transition-colors duration-200 focus:border-[#D4AF37]/60 focus:ring-2 focus:ring-[#D4AF37]/15 aria-[invalid=true]:border-[#E5484D]/60"
          {...props}
        />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          aria-label={visible ? "Hide password" : "Show password"}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-white/35 transition-colors hover:text-white/70 focus-visible:text-[#D4AF37] focus-visible:outline-none"
        >
          {visible ? <EyeOff size={16} /> : <Eye size={16} />}
        </button>
      </div>
      {error && (
        <p id={`${fieldId}-error`} className="text-xs text-[#E5484D]">
          {error}
        </p>
      )}
    </div>
  );
}

export function GoldButton({
  pending,
  children,
}: {
  pending?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      type="submit"
      disabled={pending}
      className="flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-b from-[#D4AF37] to-[#B89020] text-sm font-semibold text-[#0B0B0C] shadow-[0_8px_24px_-8px_rgba(212,175,55,0.5)] transition-all duration-200 hover:shadow-[0_10px_32px_-8px_rgba(212,175,55,0.65)] hover:brightness-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF37]/50 focus-visible:ring-offset-2 focus-visible:ring-offset-[#151517] active:scale-[0.99] disabled:opacity-60"
    >
      {pending && <Loader2 size={15} className="animate-spin" />}
      {children}
    </button>
  );
}

export function FormAlert({
  type,
  message,
}: {
  type: "error" | "success";
  message: string;
}) {
  return (
    <div
      role={type === "error" ? "alert" : "status"}
      className={
        type === "error"
          ? "rounded-xl border border-[#E5484D]/25 bg-[#E5484D]/[0.07] px-3.5 py-2.5 text-xs leading-relaxed text-[#FF8A8F]"
          : "rounded-xl border border-[#D4AF37]/25 bg-[#D4AF37]/[0.07] px-3.5 py-2.5 text-xs leading-relaxed text-[#E7CE7A]"
      }
    >
      {message}
    </div>
  );
}
