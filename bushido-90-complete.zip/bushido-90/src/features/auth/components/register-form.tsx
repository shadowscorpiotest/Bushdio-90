"use client";

import { useActionState } from "react";
import Link from "next/link";
import { register, type AuthState } from "@/actions/auth.actions";
import { AuthCard } from "./auth-card";
import { OAuthButtons } from "./oauth-buttons";
import { TextField, PasswordField, GoldButton, FormAlert } from "./fields";

export function RegisterForm() {
  const [state, formAction, pending] = useActionState<AuthState, FormData>(
    register,
    null,
  );

  if (state?.success) {
    return (
      <AuthCard title="Check your email" subtitle="One step left">
        <FormAlert type="success" message={state.success} />
        <p className="mt-5 text-center text-xs text-white/40">
          Wrong address?{" "}
          <Link
            href="/register"
            className="font-medium text-[#D4AF37] hover:text-[#E7CE7A]"
          >
            Start over
          </Link>
        </p>
      </AuthCard>
    );
  }

  return (
    <AuthCard title="Begin your 90 days" subtitle="The path starts with one account.">
      <OAuthButtons />

      <form action={formAction} className="space-y-4" noValidate>
        {state?.error && <FormAlert type="error" message={state.error} />}

        <TextField
          label="Name"
          name="displayName"
          autoComplete="name"
          placeholder="How should we address you?"
          error={state?.fieldErrors?.displayName?.[0]}
        />
        <TextField
          label="Email"
          name="email"
          type="email"
          autoComplete="email"
          placeholder="you@example.com"
          error={state?.fieldErrors?.email?.[0]}
        />
        <PasswordField
          label="Password"
          name="password"
          autoComplete="new-password"
          placeholder="8+ characters, letters and numbers"
          error={state?.fieldErrors?.password?.[0]}
        />
        <PasswordField
          label="Confirm password"
          name="confirmPassword"
          autoComplete="new-password"
          placeholder="••••••••"
          error={state?.fieldErrors?.confirmPassword?.[0]}
        />

        <GoldButton pending={pending}>Create account</GoldButton>
      </form>

      <p className="mt-6 text-center text-xs text-white/40">
        Already training?{" "}
        <Link
          href="/login"
          className="font-medium text-[#D4AF37] transition-colors hover:text-[#E7CE7A]"
        >
          Sign in
        </Link>
      </p>
    </AuthCard>
  );
}
