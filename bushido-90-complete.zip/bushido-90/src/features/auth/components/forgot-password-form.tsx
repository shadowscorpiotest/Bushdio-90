"use client";

import { useActionState } from "react";
import Link from "next/link";
import { forgotPassword, type AuthState } from "@/actions/auth.actions";
import { AuthCard } from "./auth-card";
import { TextField, GoldButton, FormAlert } from "./fields";

export function ForgotPasswordForm() {
  const [state, formAction, pending] = useActionState<AuthState, FormData>(
    forgotPassword,
    null,
  );

  return (
    <AuthCard
      title="Reset your password"
      subtitle="We'll email you a secure reset link."
    >
      <form action={formAction} className="space-y-4" noValidate>
        {state?.success && (
          <FormAlert type="success" message={state.success} />
        )}
        {state?.error && <FormAlert type="error" message={state.error} />}

        <TextField
          label="Email"
          name="email"
          type="email"
          autoComplete="email"
          placeholder="you@example.com"
          error={state?.fieldErrors?.email?.[0]}
        />

        <GoldButton pending={pending}>Send reset link</GoldButton>
      </form>

      <p className="mt-6 text-center text-xs text-white/40">
        Remembered it?{" "}
        <Link
          href="/login"
          className="font-medium text-[#D4AF37] transition-colors hover:text-[#E7CE7A]"
        >
          Back to sign in
        </Link>
      </p>
    </AuthCard>
  );
}
