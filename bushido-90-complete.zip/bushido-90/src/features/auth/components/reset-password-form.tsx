"use client";

import { useActionState } from "react";
import { resetPassword, type AuthState } from "@/actions/auth.actions";
import { AuthCard } from "./auth-card";
import { PasswordField, GoldButton, FormAlert } from "./fields";

export function ResetPasswordForm() {
  const [state, formAction, pending] = useActionState<AuthState, FormData>(
    resetPassword,
    null,
  );

  return (
    <AuthCard title="Choose a new password" subtitle="Make it strong. Keep it yours.">
      <form action={formAction} className="space-y-4" noValidate>
        {state?.error && <FormAlert type="error" message={state.error} />}

        <PasswordField
          label="New password"
          name="password"
          autoComplete="new-password"
          placeholder="8+ characters, letters and numbers"
          error={state?.fieldErrors?.password?.[0]}
        />
        <PasswordField
          label="Confirm new password"
          name="confirmPassword"
          autoComplete="new-password"
          placeholder="••••••••"
          error={state?.fieldErrors?.confirmPassword?.[0]}
        />

        <GoldButton pending={pending}>Update password</GoldButton>
      </form>
    </AuthCard>
  );
}
