"use client";

import { useActionState } from "react";
import Link from "next/link";
import { login, type AuthState } from "@/actions/auth.actions";
import { AuthCard } from "./auth-card";
import { OAuthButtons } from "./oauth-buttons";
import { TextField, PasswordField, GoldButton, FormAlert } from "./fields";

export function LoginForm({
  next,
  callbackError,
}: {
  next?: string;
  callbackError?: string;
}) {
  const [state, formAction, pending] = useActionState<AuthState, FormData>(
    login,
    null,
  );

  return (
    <AuthCard title="Welcome back" subtitle="Day by day. Rep by rep.">
      <OAuthButtons />

      <form action={formAction} className="space-y-4" noValidate>
        {next && <input type="hidden" name="next" value={next} />}

        {callbackError && (
          <FormAlert
            type="error"
            message="That sign-in link didn't work. Try again."
          />
        )}
        {state?.error && <FormAlert type="error" message={state.error} />}

        <TextField
          label="Email"
          name="email"
          type="email"
          autoComplete="email"
          placeholder="you@example.com"
          error={state?.fieldErrors?.email?.[0]}
        />

        <div className="space-y-1.5">
          <PasswordField
            label="Password"
            name="password"
            autoComplete="current-password"
            placeholder="••••••••"
            error={state?.fieldErrors?.password?.[0]}
          />
          <div className="flex justify-end">
            <Link
              href="/forgot-password"
              className="text-xs text-white/40 transition-colors hover:text-[#D4AF37]"
            >
              Forgot password?
            </Link>
          </div>
        </div>

        <GoldButton pending={pending}>Sign in</GoldButton>
      </form>

      <p className="mt-6 text-center text-xs text-white/40">
        New here?{" "}
        <Link
          href="/register"
          className="font-medium text-[#D4AF37] transition-colors hover:text-[#E7CE7A]"
        >
          Create an account
        </Link>
      </p>
    </AuthCard>
  );
}
