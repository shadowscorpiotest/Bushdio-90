"use client";

import { useOptimistic, useTransition } from "react";
import { motion } from "framer-motion";
import { Droplets, Plus, Minus } from "lucide-react";
import { WidgetCard, WidgetLabel } from "@/components/widgets/widget-card";
import { addWater } from "@/actions/tracker.actions";

const GLASS_ML = 250;

export function WaterCard({
  waterMl,
  targetMl,
}: {
  waterMl: number;
  targetMl: number;
}) {
  const [isPending, startTransition] = useTransition();
  const [optimistic, applyDelta] = useOptimistic(
    waterMl,
    (state, delta: number) => Math.max(0, state + delta),
  );

  const pct = Math.min(optimistic / targetMl, 1) * 100;

  const log = (delta: number) =>
    startTransition(async () => {
      applyDelta(delta);
      await addWater(delta);
    });

  return (
    <WidgetCard>
      <div className="mb-2.5 flex items-center justify-between">
        <WidgetLabel>
          <span className="inline-flex items-center gap-1.5">
            <Droplets size={12} className="text-[#60A5FA]" /> Hydration
          </span>
        </WidgetLabel>
        <span className="text-[12px] tabular-nums text-white/55">
          {optimistic} / {targetMl} ml
        </span>
      </div>

      <div className="relative h-24 overflow-hidden rounded-[14px] border border-edge bg-base">
        <motion.div
          animate={{ height: `${pct}%` }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          className="absolute inset-x-0 bottom-0 bg-gradient-to-b from-[#60A5FA]/75 to-[#3B82F6]/50"
        />
        <div className="absolute inset-0 flex items-center justify-center text-lg font-bold tabular-nums">
          {Math.round(pct)}%
        </div>
      </div>

      <div className="mt-3 flex gap-2">
        <button
          onClick={() => log(-GLASS_ML)}
          disabled={isPending || optimistic === 0}
          className="flex-1 rounded-[10px] border border-edge bg-base py-2 text-xs text-white/70 transition-all hover:border-gold/40 hover:text-gold active:scale-95 disabled:opacity-40"
        >
          <Minus size={12} className="mr-1 inline -translate-y-px" />
          {GLASS_ML}
        </button>
        <button
          onClick={() => log(GLASS_ML)}
          disabled={isPending}
          className="flex-[2] rounded-[10px] bg-gradient-to-b from-gold to-gold-deep py-2 text-[13px] font-semibold text-base shadow-gold-glow transition-all hover:brightness-105 active:scale-95"
        >
          <Plus size={13} className="mr-1 inline -translate-y-px" />
          Add glass
        </button>
      </div>
    </WidgetCard>
  );
}
