"use client";

import { motion } from "framer-motion";
import { Flame } from "lucide-react";
import { fadeUp } from "@/lib/framer";
import { greetingFor } from "@/utils/dates";
import { site } from "@/config/site";
import type { DashboardData } from "@/services/db/dashboard.service";

const XP_PER_LEVEL = 1000;

export function GreetingHeader({ data }: { data: DashboardData }) {
  const { profile, hour, day } = data;
  const name = profile.displayName ?? "warrior";
  const xpInLevel = profile.xp % XP_PER_LEVEL;

  return (
    <motion.header
      variants={fadeUp}
      className="flex flex-wrap items-end justify-between gap-4"
    >
      <div>
        <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-white/35">
          {day ? `Day ${day} of 90` : "Set your start date in Settings"}
        </p>
        <h1 className="mt-1.5 text-[26px] font-semibold tracking-tight">
          {greetingFor(hour)}, {name}
        </h1>
        <p className="mt-1 text-[13px] font-light text-white/40">
          "{site.quote.text}" — {site.quote.author}
        </p>
      </div>

      <div className="flex items-center gap-5">
        <div className="text-right">
          <div className="flex items-center justify-end gap-1.5">
            <motion.span
              animate={{ scale: [1, 1.15, 1], rotate: [-2, 2, -2] }}
              transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
            >
              <Flame size={18} className="text-gold" />
            </motion.span>
            <span className="text-[22px] font-bold tabular-nums">
              {profile.currentStreak}
            </span>
          </div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-white/35">
            day streak
          </p>
        </div>

        <div className="w-32">
          <div className="mb-1.5 flex justify-between text-[10px] font-semibold uppercase tracking-[0.14em]">
            <span className="text-white/35">LVL {profile.level}</span>
            <span className="tabular-nums text-gold">
              {xpInLevel}/{XP_PER_LEVEL}
            </span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-[#232326]">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(xpInLevel / XP_PER_LEVEL) * 100}%` }}
              transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
              className="h-full rounded-full bg-gradient-to-r from-gold to-gold-deep"
            />
          </div>
        </div>
      </div>
    </motion.header>
  );
}
