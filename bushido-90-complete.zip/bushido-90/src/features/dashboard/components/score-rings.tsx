"use client";

import { WidgetCard } from "@/components/widgets/widget-card";
import { RingProgress } from "@/components/widgets/ring-progress";

const RINGS = [
  { key: "bushido", label: "Bushido", color: "#D4AF37" },
  { key: "life", label: "Life", color: "#8B9DF7" },
  { key: "health", label: "Health", color: "#5FD3A5" },
  { key: "mind", label: "Mind", color: "#C88BF7" },
] as const;

export function ScoreRings({
  scores,
}: {
  scores: Record<(typeof RINGS)[number]["key"], number>;
}) {
  return (
    <WidgetCard className="flex flex-wrap justify-around gap-5">
      {RINGS.map(({ key, label, color }, i) => (
        <div key={key} className="text-center">
          <RingProgress value={scores[key]} color={color} delay={i * 140}>
            <span className="text-[17px] font-bold tabular-nums">
              {scores[key]}
            </span>
          </RingProgress>
          <p className="mt-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-white/35">
            {label}
          </p>
        </div>
      ))}
    </WidgetCard>
  );
}
