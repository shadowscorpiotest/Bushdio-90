"use client";

import { useOptimistic, useTransition } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { Check, ArrowUpRight } from "lucide-react";
import { WidgetCard, WidgetLabel } from "@/components/widgets/widget-card";
import { toggleTask } from "@/actions/tasks.actions";
import { cn } from "@/utils/cn";
import type { DashboardData } from "@/services/db/dashboard.service";

type Task = DashboardData["tasks"][number];

export function MissionCard({ tasks }: { tasks: Task[] }) {
  const [isPending, startTransition] = useTransition();
  const [optimistic, applyToggle] = useOptimistic(
    tasks,
    (state, id: string) =>
      state.map((t) =>
        t.id === id
          ? { ...t, status: t.status === "DONE" ? "TODO" : "DONE" }
          : t,
      ) as Task[],
  );

  const done = optimistic.filter((t) => t.status === "DONE").length;

  const onToggle = (id: string) =>
    startTransition(async () => {
      applyToggle(id);
      await toggleTask(id);
    });

  return (
    <WidgetCard className="lg:col-span-1">
      <div className="mb-2 flex items-center justify-between">
        <WidgetLabel>Today's Mission</WidgetLabel>
        <span className="text-[10px] font-semibold tabular-nums tracking-[0.14em] text-gold">
          {done}/{optimistic.length}
        </span>
      </div>

      {optimistic.length === 0 && (
        <div className="py-6 text-center">
          <p className="text-[13px] text-white/45">
            No tasks scheduled for today.
          </p>
          <Link
            href="/today"
            className="mt-2 inline-flex items-center gap-1 text-[12px] font-medium text-gold hover:text-gold-soft"
          >
            Plan the day <ArrowUpRight size={12} />
          </Link>
        </div>
      )}

      {optimistic.map((t) => {
        const isDone = t.status === "DONE";
        return (
          <button
            key={t.id}
            onClick={() => onToggle(t.id)}
            disabled={isPending}
            className="group flex w-full items-center gap-3 rounded-xl px-2.5 py-3 text-left transition-colors hover:bg-white/[0.03]"
          >
            <motion.span
              animate={
                isDone
                  ? { scale: [0.6, 1.15, 1], backgroundColor: "#D4AF37", borderColor: "#D4AF37" }
                  : { scale: 1, backgroundColor: "rgba(0,0,0,0)", borderColor: "#3a3a3e" }
              }
              transition={{ type: "spring", stiffness: 420, damping: 20 }}
              className="flex h-[22px] w-[22px] shrink-0 items-center justify-center rounded-lg border-[1.5px] text-base"
            >
              <AnimatePresence>
                {isDone && (
                  <motion.span
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0, opacity: 0 }}
                  >
                    <Check size={14} strokeWidth={3.5} className="text-base text-[#0B0B0C]" />
                  </motion.span>
                )}
              </AnimatePresence>
            </motion.span>
            <span className="relative text-[13.5px] text-white/85 transition-colors duration-300 group-hover:text-white">
              <span className={cn(isDone && "text-white/30")}>{t.title}</span>
              <span
                className={cn(
                  "absolute left-0 top-1/2 h-px bg-white/35 transition-all duration-500",
                  isDone ? "w-full" : "w-0",
                )}
              />
            </span>
          </button>
        );
      })}
    </WidgetCard>
  );
}
