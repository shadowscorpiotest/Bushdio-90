"use client";

import { motion } from "framer-motion";
import { stagger } from "@/lib/framer";
import type { DashboardData } from "@/services/db/dashboard.service";
import { GreetingHeader } from "./greeting-header";
import { ScoreRings } from "./score-rings";
import { MissionCard } from "./mission-card";
import { WaterCard } from "./water-card";
import { VitalsCard } from "./vitals-card";

export function DashboardView({ data }: { data: DashboardData }) {
  return (
    <motion.div
      variants={stagger}
      initial="hidden"
      animate="show"
      className="grid grid-cols-1 gap-3.5 lg:grid-cols-3"
    >
      <div className="lg:col-span-3">
        <GreetingHeader data={data} />
      </div>
      <div className="lg:col-span-3">
        <ScoreRings scores={data.scores} />
      </div>
      <MissionCard tasks={data.tasks} />
      <WaterCard
        waterMl={data.waterMl}
        targetMl={data.profile.settings?.waterTargetMl ?? 2500}
      />
      <VitalsCard vitals={data.vitals} settings={data.profile.settings} />
    </motion.div>
  );
}
