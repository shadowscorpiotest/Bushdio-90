"use client";

import { motion } from "framer-motion";
import { Moon, Brain, Dumbbell } from "lucide-react";
import { WidgetCard, WidgetLabel } from "@/components/widgets/widget-card";
import type { DashboardData } from "@/services/db/dashboard.service";

function VitalBar({
  icon: Icon,
  name,
  text,
  value,
  max,
  color,
  delay,
}: {
  icon: typeof Moon;
  name: string;
  text: string;
  value: number;
  max: number;
  color: string;
  delay: number;
}) {
  return (
    <div className="mb-3.5 last:mb-0">
      <div className="mb-1.5 flex justify-between">
        <span className="inline-flex items-center gap-1.5 text-[12.5px] text-white/70">
          <Icon size={13} style={{ color }} /> {name}
        </span>
        <span className="text-[12px] tabular-nums text-white/40">{text}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-[#232326]">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${Math.min(value / max, 1) * 100}%` }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay }}
          className="h-full rounded-full"
          style={{ background: `linear-gradient(90deg, ${color}, ${color}bb)` }}
        />
      </div>
    </div>
  );
}

export function VitalsCard({
  vitals,
  settings,
}: {
  vitals: DashboardData["vitals"];
  settings: DashboardData["profile"]["settings"];
}) {
  const sleepTarget = settings?.sleepTargetMin ?? 480;
  const deepWorkTarget = settings?.deepWorkTargetMin ?? 120;

  const fmtH = (min: number) => `${Math.floor(min / 60)}h ${min % 60}m`;

  return (
    <WidgetCard>
      <WidgetLabel>Vitals</WidgetLabel>
      <div className="mt-3.5">
        <VitalBar
          icon={Moon}
          name="Sleep"
          text={vitals.sleepMin ? fmtH(vitals.sleepMin) : "not logged"}
          value={vitals.sleepMin}
          max={sleepTarget}
          color="#8B9DF7"
          delay={0.1}
        />
        <VitalBar
          icon={Brain}
          name="Deep work"
          text={vitals.deepWorkMin ? `${vitals.deepWorkMin} min` : "not yet"}
          value={vitals.deepWorkMin}
          max={deepWorkTarget}
          color="#C88BF7"
          delay={0.22}
        />
        <VitalBar
          icon={Dumbbell}
          name="Training"
          text={vitals.workoutDone ? "done 武" : "pending"}
          value={vitals.workoutDone ? 1 : 0}
          max={1}
          color="#D4AF37"
          delay={0.34}
        />
      </div>
    </WidgetCard>
  );
}
