/**
 * "Today" in the user's timezone, normalized to UTC midnight —
 * matches how @db.Date columns are stored in the Phase 2 schema.
 */
export function localToday(timezone: string, now = new Date()): Date {
  const ymd = new Intl.DateTimeFormat("en-CA", { timeZone: timezone }).format(now);
  return new Date(`${ymd}T00:00:00.000Z`);
}

export function localHour(timezone: string, now = new Date()): number {
  return Number(
    new Intl.DateTimeFormat("en-US", {
      timeZone: timezone,
      hour: "numeric",
      hour12: false,
    }).format(now),
  );
}

export function greetingFor(hour: number): string {
  if (hour < 5) return "Late night";
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

/** 1-based day of the 90-day challenge, clamped to 1..90. */
export function challengeDay(start: Date | null, today: Date): number | null {
  if (!start) return null;
  const diff = Math.floor((today.getTime() - start.getTime()) / 86_400_000) + 1;
  return Math.min(Math.max(diff, 1), 90);
}
