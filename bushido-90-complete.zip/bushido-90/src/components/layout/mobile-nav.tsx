"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { NAV } from "@/config/nav";
import { cn } from "@/utils/cn";

export function MobileNav() {
  const pathname = usePathname();
  const items = NAV.filter((n) => n.mobile).slice(0, 5);

  return (
    <nav className="fixed inset-x-0 bottom-0 z-50 flex justify-around border-t border-[#1d1d20] bg-base/90 px-2 pb-[calc(10px+env(safe-area-inset-bottom))] pt-2 backdrop-blur-xl md:hidden">
      {items.map(({ key, label, href, icon: Icon }) => {
        const active = pathname.startsWith(href);
        return (
          <Link
            key={key}
            href={href}
            className={cn(
              "flex flex-col items-center gap-0.5 rounded-xl px-3 py-1 text-[9.5px] font-medium text-white/40 transition-colors",
              active && "text-gold",
            )}
          >
            <motion.span animate={{ y: active ? -2 : 0, scale: active ? 1.08 : 1 }}
              transition={{ type: "spring", stiffness: 420, damping: 22 }}>
              <Icon size={19} />
            </motion.span>
            {label.split(" ")[0]}
          </Link>
        );
      })}
    </nav>
  );
}
