"use client";

import { usePathname } from "next/navigation";
import { LogOut } from "lucide-react";
import { NAV } from "@/config/nav";
import { logout } from "@/actions/auth.actions";

export function TopNav() {
  const pathname = usePathname();
  const current = NAV.find((n) => pathname.startsWith(n.href));

  return (
    <header className="sticky top-0 z-40 flex h-14 items-center justify-between border-b border-[#1d1d20] bg-base/80 px-4 backdrop-blur-xl md:px-7">
      <div className="flex items-center gap-2 text-[13px]">
        <span className="text-white/30">Bushido 90</span>
        <span className="text-white/20">/</span>
        <span className="font-medium text-white/80">
          {current?.label ?? "Dashboard"}
        </span>
      </div>
      <form action={logout}>
        <button
          type="submit"
          className="flex items-center gap-2 rounded-lg border border-edge bg-card px-3 py-1.5 text-xs text-white/60 transition-colors hover:border-gold/40 hover:text-gold"
        >
          <LogOut size={13} />
          Sign out
        </button>
      </form>
    </header>
  );
}
