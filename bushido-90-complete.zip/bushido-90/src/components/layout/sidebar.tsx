"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { ChevronLeft } from "lucide-react";
import { NAV } from "@/config/nav";
import { site } from "@/config/site";
import { cn } from "@/utils/cn";
import { EASE } from "@/lib/framer";

export function Sidebar({
  collapsed,
  onToggle,
}: {
  collapsed: boolean;
  onToggle: () => void;
}) {
  const pathname = usePathname();

  return (
    <motion.aside
      animate={{ width: collapsed ? 68 : 228 }}
      transition={{ duration: 0.4, ease: EASE }}
      className="sticky top-0 hidden h-dvh shrink-0 flex-col overflow-hidden whitespace-nowrap border-r border-[#1d1d20] px-3 py-5 md:flex"
    >
      {/* Wordmark */}
      <Link href="/dashboard" className="mb-6 flex items-center gap-2.5 px-1.5">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-edge bg-card text-[15px] text-gold shadow-gold-glow">
          {site.mark}
        </span>
        <motion.span
          animate={{ opacity: collapsed ? 0 : 1 }}
          transition={{ duration: 0.2 }}
          className="text-xs font-bold tracking-[0.28em] text-white"
        >
          BUSHIDO 90
        </motion.span>
      </Link>

      {/* Nav */}
      <nav className="flex flex-1 flex-col gap-1 overflow-y-auto">
        {NAV.map(({ key, label, href, icon: Icon }) => {
          const active = pathname.startsWith(href);
          return (
            <Link
              key={key}
              href={href}
              className={cn(
                "group relative flex items-center gap-3 rounded-xl border border-transparent px-3 py-2.5 text-[13px] font-medium text-white/55 transition-all duration-200 hover:translate-x-0.5 hover:bg-white/[0.04] hover:text-white",
                active &&
                  "border-gold/25 bg-gold/[0.08] text-gold hover:translate-x-0 hover:bg-gold/[0.08] hover:text-gold",
              )}
            >
              {active && (
                <motion.span
                  layoutId="nav-glow"
                  className="absolute inset-0 -z-10 rounded-xl shadow-gold-glow"
                  transition={{ duration: 0.35, ease: EASE }}
                />
              )}
              <Icon size={17} className="shrink-0" />
              <motion.span
                animate={{ opacity: collapsed ? 0 : 1 }}
                transition={{ duration: 0.2 }}
              >
                {label}
              </motion.span>
            </Link>
          );
        })}
      </nav>

      {/* Collapse */}
      <button
        onClick={onToggle}
        className="mt-2 flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-medium text-white/40 transition-colors hover:bg-white/[0.04] hover:text-white"
      >
        <motion.span
          animate={{ rotate: collapsed ? 180 : 0 }}
          transition={{ duration: 0.4, ease: EASE }}
          className="shrink-0"
        >
          <ChevronLeft size={17} />
        </motion.span>
        <motion.span animate={{ opacity: collapsed ? 0 : 1 }}>Collapse</motion.span>
      </button>
    </motion.aside>
  );
}
