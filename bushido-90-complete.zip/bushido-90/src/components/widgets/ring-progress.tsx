"use client";

import { useEffect, useState, type ReactNode } from "react";

export function RingProgress({
  value,          // 0–100
  size = 74,
  stroke = 6,
  color = "#D4AF37",
  delay = 0,
  children,
}: {
  value: number;
  size?: number;
  stroke?: number;
  color?: string;
  delay?: number;
  children?: ReactNode;
}) {
  const [v, setV] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setV(Math.min(Math.max(value, 0), 100)), 200 + delay);
    return () => clearTimeout(t);
  }, [value, delay]);

  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#232326" strokeWidth={stroke} />
        <circle
          cx={size / 2} cy={size / 2} r={r} fill="none"
          stroke={color} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c - (v / 100) * c}
          style={{
            transition: "stroke-dashoffset 1.3s cubic-bezier(.22,1,.36,1)",
            filter: `drop-shadow(0 0 6px ${color}55)`,
          }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        {children}
      </div>
    </div>
  );
}
