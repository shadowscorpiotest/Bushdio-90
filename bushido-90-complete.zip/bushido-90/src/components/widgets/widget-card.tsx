"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { cn } from "@/utils/cn";
import { fadeUp } from "@/lib/framer";

export function WidgetCard({
  children,
  className,
  interactive = true,
}: {
  children: ReactNode;
  className?: string;
  interactive?: boolean;
}) {
  return (
    <motion.section
      variants={fadeUp}
      whileHover={interactive ? { y: -3 } : undefined}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className={cn(
        "rounded-xl2 border border-edge bg-card/85 p-[18px] shadow-card backdrop-blur-xl",
        interactive &&
          "transition-colors duration-300 hover:border-gold/35 hover:shadow-gold-glow",
        className,
      )}
    >
      {children}
    </motion.section>
  );
}

export function WidgetLabel({ children }: { children: ReactNode }) {
  return (
    <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-white/35">
      {children}
    </p>
  );
}
