"use server";

import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { localToday } from "@/utils/dates";

/**
 * Log a value against any registered metric for "today"
 * in the user's timezone. Powers water, mood, reading, etc.
 */
export async function logMetric(metricKey: string, value: number) {
  const user = await requireUser();

  const [profile, metric] = await Promise.all([
    prisma.user.findUniqueOrThrow({
      where: { id: user.id },
      select: { timezone: true },
    }),
    prisma.metricDefinition.findUnique({ where: { key: metricKey } }),
  ]);

  if (!metric) {
    return { error: `Unknown metric "${metricKey}". Run the metric seed.` };
  }
  if (metric.minValue !== null && value < metric.minValue) {
    return { error: "Value below allowed range." };
  }
  if (metric.maxValue !== null && value > metric.maxValue) {
    return { error: "Value above allowed range." };
  }

  await prisma.metricLog.create({
    data: {
      userId: user.id,
      metricId: metric.id,
      date: localToday(profile.timezone),
      value,
    },
  });

  revalidatePath("/dashboard");
  return { ok: true };
}

export async function addWater(amountMl: number) {
  // Negative amounts allowed for corrections, bounded for sanity.
  if (!Number.isFinite(amountMl) || Math.abs(amountMl) > 2000) {
    return { error: "Invalid amount." };
  }
  return logMetric("water_intake", amountMl);
}
