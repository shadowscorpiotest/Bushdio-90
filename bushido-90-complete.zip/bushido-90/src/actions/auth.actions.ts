"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import {
  loginSchema,
  registerSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
} from "@/features/auth/schemas";

export type AuthState = {
  error?: string;
  success?: string;
  fieldErrors?: Record<string, string[] | undefined>;
} | null;

const siteUrl = () =>
  process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

/**
 * Idempotent provisioning of the app-side user record.
 * Called on register and on every OAuth/confirmation callback.
 */
export async function ensureUserRecord(params: {
  id: string;
  email: string;
  displayName?: string | null;
  avatarUrl?: string | null;
}) {
  await prisma.user.upsert({
    where: { id: params.id },
    update: {},
    create: {
      id: params.id,
      email: params.email,
      displayName: params.displayName ?? params.email.split("@")[0],
      avatarUrl: params.avatarUrl ?? null,
      settings: { create: {} },
    },
  });
}

// ── Login ────────────────────────────────────────────────

export async function login(
  _prev: AuthState,
  formData: FormData,
): Promise<AuthState> {
  const parsed = loginSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) {
    return { fieldErrors: parsed.error.flatten().fieldErrors };
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword(parsed.data);

  if (error) {
    return {
      error:
        error.code === "invalid_credentials"
          ? "Incorrect email or password"
          : "Sign in failed. Try again.",
    };
  }

  const next = (formData.get("next") as string) || "/dashboard";
  redirect(next.startsWith("/") ? next : "/dashboard");
}

// ── Register ─────────────────────────────────────────────

export async function register(
  _prev: AuthState,
  formData: FormData,
): Promise<AuthState> {
  const parsed = registerSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) {
    return { fieldErrors: parsed.error.flatten().fieldErrors };
  }

  const { email, password, displayName } = parsed.data;
  const supabase = await createClient();

  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { display_name: displayName },
      emailRedirectTo: `${siteUrl()}/api/auth/callback`,
    },
  });

  if (error) {
    return {
      error:
        error.code === "user_already_exists"
          ? "An account with this email already exists"
          : "Sign up failed. Try again.",
    };
  }

  if (data.user) {
    await ensureUserRecord({ id: data.user.id, email, displayName });
  }

  // Email confirmation on (no session yet)
  if (!data.session) {
    return {
      success: "Check your inbox — we sent a confirmation link to " + email,
    };
  }

  redirect("/dashboard");
}

// ── Logout ───────────────────────────────────────────────

export async function logout() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/login");
}

// ── Forgot password ──────────────────────────────────────

export async function forgotPassword(
  _prev: AuthState,
  formData: FormData,
): Promise<AuthState> {
  const parsed = forgotPasswordSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) {
    return { fieldErrors: parsed.error.flatten().fieldErrors };
  }

  const supabase = await createClient();
  await supabase.auth.resetPasswordForEmail(parsed.data.email, {
    redirectTo: `${siteUrl()}/api/auth/callback?next=/reset-password`,
  });

  // Always report success — never reveal whether an email is registered.
  return {
    success: "If that email has an account, a reset link is on its way.",
  };
}

// ── Reset password ───────────────────────────────────────

export async function resetPassword(
  _prev: AuthState,
  formData: FormData,
): Promise<AuthState> {
  const parsed = resetPasswordSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) {
    return { fieldErrors: parsed.error.flatten().fieldErrors };
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({
    password: parsed.data.password,
  });

  if (error) {
    return { error: "Reset link expired. Request a new one." };
  }

  redirect("/dashboard");
}

// ── Google OAuth ─────────────────────────────────────────

export async function signInWithGoogle() {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: "google",
    options: { redirectTo: `${siteUrl()}/api/auth/callback` },
  });

  if (error || !data.url) redirect("/login?error=oauth");
  redirect(data.url);
}
