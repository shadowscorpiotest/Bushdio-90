"use server";

import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const TASK_XP = 20;

/**
 * Toggle a task between TODO and DONE, awarding/removing XP
 * atomically. Optimistic UI on the client makes this feel instant.
 */
export async function toggleTask(taskId: string) {
  const user = await requireUser();

  const task = await prisma.task.findFirst({
    where: { id: taskId, userId: user.id },
    select: { id: true, status: true },
  });
  if (!task) return { error: "Task not found." };

  const completing = task.status !== "DONE";

  await prisma.$transaction([
    prisma.task.update({
      where: { id: task.id },
      data: {
        status: completing ? "DONE" : "TODO",
        completedAt: completing ? new Date() : null,
      },
    }),
    prisma.user.update({
      where: { id: user.id },
      data: { xp: { [completing ? "increment" : "decrement"]: TASK_XP } },
    }),
    ...(completing
      ? [
          prisma.xpEvent.create({
            data: {
              userId: user.id,
              amount: TASK_XP,
              reason: "task_completed",
              sourceType: "task",
              sourceId: task.id,
            },
          }),
        ]
      : []),
  ]);

  revalidatePath("/dashboard");
  revalidatePath("/today");
  return { ok: true, xp: completing ? TASK_XP : -TASK_XP };
}
