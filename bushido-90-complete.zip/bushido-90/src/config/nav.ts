import {
  LayoutDashboard, Target, Swords, HeartPulse, UtensilsCrossed,
  Dumbbell, FolderKanban, Flag, CalendarDays, GraduationCap,
  Library, NotebookPen, BarChart3, Sparkles, Settings,
  type LucideIcon,
} from "lucide-react";

export type NavItem = {
  key: string;
  label: string;
  href: string;
  icon: LucideIcon;
  /** shown in the mobile bottom bar (max 5) */
  mobile?: boolean;
};

export const NAV: NavItem[] = [
  { key: "dashboard", label: "Dashboard", href: "/dashboard", icon: LayoutDashboard, mobile: true },
  { key: "today", label: "Today's Mission", href: "/today", icon: Target, mobile: true },
  { key: "bushido", label: "Bushido", href: "/bushido", icon: Swords, mobile: true },
  { key: "health", label: "Health", href: "/health", icon: HeartPulse },
  { key: "nutrition", label: "Nutrition", href: "/nutrition", icon: UtensilsCrossed },
  { key: "workout", label: "Workout", href: "/workout", icon: Dumbbell },
  { key: "projects", label: "Projects", href: "/projects", icon: FolderKanban },
  { key: "goals", label: "Goals", href: "/goals", icon: Flag },
  { key: "calendar", label: "Calendar", href: "/calendar", icon: CalendarDays },
  { key: "learning", label: "Learning", href: "/learning", icon: GraduationCap },
  { key: "knowledge", label: "Knowledge", href: "/knowledge", icon: Library },
  { key: "journal", label: "Journal", href: "/journal", icon: NotebookPen, mobile: true },
  { key: "analytics", label: "Analytics", href: "/analytics", icon: BarChart3, mobile: true },
  { key: "coach", label: "AI Coach", href: "/coach", icon: Sparkles },
  { key: "settings", label: "Settings", href: "/settings", icon: Settings },
];
