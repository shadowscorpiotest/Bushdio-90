export const site = {
  name: "Bushido 90",
  mark: "武",
  tagline: "Become your strongest self",
  quote: { text: "The way is in training.", author: "Miyamoto Musashi" },
} as const;
