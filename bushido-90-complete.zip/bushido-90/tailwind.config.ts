import type { Config } from "tailwindcss";

export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        base: "#0B0B0C",
        card: "#151517",
        edge: "#2A2A2D",
        gold: { DEFAULT: "#D4AF37", deep: "#B89020", soft: "#E7CE7A" },
        danger: "#E5484D",
      },
      fontFamily: { sans: ["var(--font-inter)", "Inter", "sans-serif"] },
      borderRadius: { xl2: "18px" },
      boxShadow: {
        card: "0 24px 64px -32px rgba(0,0,0,0.85)",
        "gold-glow": "0 0 32px -12px rgba(212,175,55,0.45)",
      },
      keyframes: {
        "fade-up": {
          from: { opacity: "0", transform: "translateY(14px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: { "fade-up": "fade-up .55s cubic-bezier(.22,1,.36,1) both" },
    },
  },
  plugins: [],
} satisfies Config;
