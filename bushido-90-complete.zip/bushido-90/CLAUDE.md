# Bushido 90

AI-powered Life Operating System. 90-day discipline challenge app.
Luxury dark theme: bg #0B0B0C, cards #151517, borders #2A2A2D, gold #D4AF37.

## Stack
Next.js 15 (App Router) · React 19 · TypeScript · Tailwind v3 (NOT v4 —
config is tailwind.config.ts) · Prisma + Supabase Postgres · Supabase Auth
(@supabase/ssr) · Framer Motion · lucide-react · Zod.

## Architecture rules
- Feature-based: `src/app` is routing only; UI lives in `src/features/*`,
  shared primitives in `src/components/*`.
- Reads: server components calling `src/services/db/*`.
  Mutations: Server Actions in `src/actions/*` + `useOptimistic` on the client.
- Zustand only for pure UI state (not yet needed). Never store server data in it.
- "Today" must always be computed via `localToday(user.timezone)` from
  `src/utils/dates.ts` — dates are stored as UTC-midnight @db.Date.
- Simple tracking (sleep, water, mood…) goes through the generic
  MetricDefinition/MetricLog engine — do NOT create new tables for these.
- Auth guard: `requireUser()` from `src/lib/auth.ts` in every protected
  page and action. New Supabase users must go through `ensureUserRecord`.
- Nav: add routes only in `src/config/nav.ts` (single source of truth).

## Commands
- `npm run dev` — start
- `npm run db:migrate` — Prisma migrate (needs .env.local with DATABASE_URL + DIRECT_URL)
- `npm run db:seed` — seed metric registry (required once)
- `npm run db:studio` — inspect data

## Setup state
Phases shipped: folder structure, full Prisma schema, auth (email +
Google OAuth), app shell + dashboard. Remaining phases: today/mission
planner, bushido virtues, tracker pages, nutrition, workout, projects,
goals, calendar, journal, knowledge, analytics, AI coach, settings.

## Environment
Copy .env.example → .env.local. Requires a Supabase project:
URL + anon key, pooled + direct DB URLs, and the redirect URL
`http://localhost:3000/api/auth/callback` registered in
Supabase Auth → URL Configuration.

## Style
No bootstrap-feel. Rounded-xl2 cards, restrained gold accents, one easing
everywhere: cubic-bezier(.22,1,.36,1). Respect prefers-reduced-motion.
